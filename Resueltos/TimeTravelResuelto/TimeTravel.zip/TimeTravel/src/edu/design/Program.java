package edu.design;

import java.util.Date;

import edu.palermo.ds.ejercicios.fechas.UnixTimeMachine;

public class Program {
	public static void main(String[] args) {
		UnixTimeMachine granInvento = new UnixTimeMachine();
		ExistingSystem myBoss = new ExistingSystem();
		
		Date dateToJump = myBoss.WhenToJumpTo();
		
		granInvento.timejump(dateToJump); //UPS
		
		
	}

}
